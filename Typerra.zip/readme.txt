Enable these flags:
chrome://flags/#writer-api-for-gemini-nano
chrome://flags/#proofreader-api-for-gemini-nano
chrome://flags/#rewriter-api-for-gemini-nano
chrome://flags/#prompt-api-for-gemini-nano
Relaunch Chrome.


Use the load unpacked feature and load the dist folder as an extension